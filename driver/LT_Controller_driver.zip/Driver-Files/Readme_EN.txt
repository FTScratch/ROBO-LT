This Driver supports:

  Windows 2000
  Windows XP (32 and 64 bit)
  Windows Vista (32 and 64 bit)
  Windows  7 (32 and 64 bit)
  Windows  8 (32 und 64 Bit)
  Windows 10 (32 und 64 Bit)

To install the driver use the Setup.exe Tool. When a supported product is connected
to the system it finds the related driver and install it.

For Windows 98 / Me use the older 32bit driver from the "Win98" folder.

Supported products (updated 2014)
 - Robo Interface / Robo IO-Extension / Robo RF-DataLink / Robo LT-Controller
 - Robo-Connect-Box
 - education line by Knobloch:  CrossRoads / TrafficLights / Signal  (www.knobloch-gmbh.de)


*******************************************************************************
Disclaimer for KeUsb driver software from Knobloch GmbH

Knobloch GmbH excludes any responsibility for the KeUsb driver software 
- irrespective of  which legal ground -, as far as this is legally permissible. 

The KeUsb-driver-software is meant to control hardware interfaces over the USB-Port. 
Their functionality is limited and can be affected by numerous factors, such as 
current fluctuations, malfunctionings of the hardware and other things. 
The user of the KeUsb-driver-software has to therefore to make sure that the 
software is not used, if when using the software an injury of persons or a 
damage of things is not to be excluded. 

Knobloch GmbH excludes a responsibility for the KeUsb-driver-software related 
to the malfunctionings of the program, a responsibility for data loss, 
damages to the PC, as well as a responsibility for damages resulting in 
relation with the use of programs, which uses the KeUsb-driver-software  

The responsibility of Knobloch GmbH, according to the product liability law, 
remains unaffected by the preceding disclaimer.


Use Agreement KeUsb driver software from Knobloch GmbH

The KeUsb driver software can not refer to somebody without our consent and is 
only for the use of supported Products approved. The software can be downloaded 
for free on the Internet at www.knobloch-gmbh.de. 
It is not permitted to change the files.

(c) 2010, 2011, 2014, 2015
    Knobloch GmbH - Germany
    www.knobloch-gmbh.de